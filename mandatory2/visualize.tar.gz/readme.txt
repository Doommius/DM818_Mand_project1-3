Usage:
1. Run the simulation program with "-o <filename>" option.
2. Run "visualize <filename>" with the file produced.
